﻿define(
   ({
    _widgetLabel: "Otsi",
    searchResult: "Otsi tulemusi",
    showAllResults: "Näita otsingutulemusi päringule ",
    showAll: "Näita otsingutulemusi",
    more: "rohkem",
    untitled: "Pealkirjata"
  })
);