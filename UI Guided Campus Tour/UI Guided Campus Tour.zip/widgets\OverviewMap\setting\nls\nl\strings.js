﻿define(
   ({
    visible: "Overzichtskaart standaard weergeven",
    minWidth: "Min. breedte",
    minHeight: "Min. hoogte",
    maxWidth: "Max. breedte",
    maxHeight: "Max. hoogte",
    minText: "Minimum",
    maxText: "maximum",
    attachText: "Geef op welke hoek van de kaart aan deze widget moet worden bevestigd.",
    expandText: "Klap de widget eerst uit",
    topLeft: "Linksboven",
    topRight: "Rechtsboven",
    bottomLeft: "Linksonder",
    bottomRight: "Rechtsonder"
  })
);