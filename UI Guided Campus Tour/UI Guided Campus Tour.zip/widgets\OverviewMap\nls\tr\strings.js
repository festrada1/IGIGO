﻿define(
   ({
    _widgetLabel: "Genel Bakış Haritası"
  })
);