﻿define(
   ({
    _widgetLabel: "Podgląd mapy"
  })
);