﻿define(
   ({
    _widgetLabel: "検索",
    searchResult: "検索結果",
    showAllResults: "検索結果の表示 ",
    showAll: "検索結果の表示",
    more: "その他",
    untitled: "無題"
  })
);