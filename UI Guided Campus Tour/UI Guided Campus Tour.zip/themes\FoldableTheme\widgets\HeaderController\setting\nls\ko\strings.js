﻿define(
   ({
    group: "이름",
    openAll: "패널의 모든 항목 열기",
    dropDown: "드롭다운 메뉴에 표시",
    noGroup: "위젯 그룹 세트가 없습니다.",
    groupSetLabel: "위젯 그룹 등록정보 설정"
  })
);