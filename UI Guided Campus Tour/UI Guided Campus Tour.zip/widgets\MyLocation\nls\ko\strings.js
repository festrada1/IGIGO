﻿define(
   ({
    _widgetLabel: "내 위치",
    title: "내 위치 찾기",
    browserError: "지오로케이션은 이 브라우저에서 지원되지 않습니다.",
    failureFinding: "사용자의 위치를 찾을 수 없습니다. 사용자의 위치가 공유되어 있는지 알아보려면 브라우저를 확인하세요."
  })
);