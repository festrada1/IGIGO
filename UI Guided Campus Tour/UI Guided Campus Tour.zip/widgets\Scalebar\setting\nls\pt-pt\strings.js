﻿define(
   ({
    unit: "Unidade",
    style: "Estilo",
    dual: "duplo",
    english: "inglês",
    metric: "métrico",
    ruler: "régua",
    line: "linha"
  })
);