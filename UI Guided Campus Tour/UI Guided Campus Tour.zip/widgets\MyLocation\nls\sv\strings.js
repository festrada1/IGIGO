﻿define(
   ({
    _widgetLabel: "Min plats",
    title: "Hitta min plats",
    browserError: "Den här webbläsaren har inte stöd för geolokalisering.",
    failureFinding: "Det går inte att hitta din plats. Kontrollera i webbläsaren att platsen är delad."
  })
);