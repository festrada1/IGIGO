﻿define(
   ({
    visible: "Wyświetlaj domyślnie mapę przeglądową",
    minWidth: "Szerokość min.",
    minHeight: "Wysokość min.",
    maxWidth: "Szerokość maks.",
    maxHeight: "Wysokość maks.",
    minText: "Minimum",
    maxText: "maksimum",
    attachText: "Podaj narożnik mapy, do którego ma zostać dołączony ten widżet.",
    expandText: "Wstępnie rozwiń widżet",
    topLeft: "Górny lewy",
    topRight: "Górny prawy",
    bottomLeft: "Dolny lewy",
    bottomRight: "Dolny prawy"
  })
);