﻿define(
   ({
    _widgetLabel: "Pulsante Home"
  })
);