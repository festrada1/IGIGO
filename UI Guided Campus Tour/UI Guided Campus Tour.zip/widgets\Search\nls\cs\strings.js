﻿define(
   ({
    _widgetLabel: "Hledat",
    searchResult: "Výsledek vyhledávání",
    showAllResults: "Zobrazit výsledky vyhledávání pro ",
    showAll: "Zobrazit výsledky vyhledávání",
    more: "více",
    untitled: "Bez názvu"
  })
);