﻿define(
   ({
    _widgetLabel: "แถบสเกล"
  })
);