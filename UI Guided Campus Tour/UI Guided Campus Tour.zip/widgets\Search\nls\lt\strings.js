﻿define(
   ({
    _widgetLabel: "Ieškoti",
    searchResult: "Paieškos rezultatas",
    showAllResults: "Rodyti rezultatus, susijusius su ",
    showAll: "Rodyti paieškos rezultatus",
    more: "daugiau",
    untitled: "Bevardis"
  })
);