﻿define(
   ({
    unit: "单位",
    style: "样式",
    dual: "中心",
    english: "英语",
    metric: "公制",
    ruler: "标尺",
    line: "线"
  })
);