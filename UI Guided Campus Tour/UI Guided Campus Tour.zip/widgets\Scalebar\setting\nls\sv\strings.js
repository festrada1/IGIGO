﻿define(
   ({
    unit: "Enhet",
    style: "Format",
    dual: "dubbel",
    english: "metric",
    metric: "metric",
    ruler: "linjal",
    line: "linje"
  })
);