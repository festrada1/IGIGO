﻿define(
   ({
    _widgetLabel: "Mittakaava"
  })
);