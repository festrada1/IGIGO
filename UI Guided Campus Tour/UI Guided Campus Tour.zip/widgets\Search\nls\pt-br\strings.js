﻿define(
   ({
    _widgetLabel: "Pesquisar",
    searchResult: "Resultado de pesquisa",
    showAllResults: "Mostrar resultados da pesquisa para ",
    showAll: "Mostrar resultados da pesquisa",
    more: "mais",
    untitled: "Sem título"
  })
);