﻿define(
   ({
    timeout: "Pārtraukums",
    highlightLocation: "Izcelt atrašanās vietu",
    useTracking: "Skatīties atrašanās vietas izmaiņas",
    warning: "Nepareiza ievade"
  })
);