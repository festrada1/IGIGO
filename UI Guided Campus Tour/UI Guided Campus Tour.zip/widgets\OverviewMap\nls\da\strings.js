﻿define(
   ({
    _widgetLabel: "Oversigtskort"
  })
);