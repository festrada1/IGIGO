﻿define(
   ({
    _widgetLabel: "搜索",
    searchResult: "搜索结果",
    showAllResults: "显示搜索结果 ",
    showAll: "显示搜索结果",
    more: "更多",
    untitled: "无标题"
  })
);