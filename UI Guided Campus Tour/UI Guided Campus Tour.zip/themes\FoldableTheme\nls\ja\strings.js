﻿define(
   ({
    _themeLabel: "折りたたみ可能なテーマ",
    _layout_default: "デフォルトのレイアウト",
    _layout_layout1: "レイアウト 1"
  })
);