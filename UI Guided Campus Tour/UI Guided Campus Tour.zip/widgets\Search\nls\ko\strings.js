﻿define(
   ({
    _widgetLabel: "검색",
    searchResult: "검색 결과",
    showAllResults: "다음에 대한 검색 결과 보기 ",
    showAll: "검색 결과 보기",
    more: "기타",
    untitled: "제목 없음"
  })
);