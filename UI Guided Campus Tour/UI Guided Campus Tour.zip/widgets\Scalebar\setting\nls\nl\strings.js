﻿define(
   ({
    unit: "Eenheid",
    style: "Stijl",
    dual: "dubbel",
    english: "Engels",
    metric: "metrisch",
    ruler: "liniaal",
    line: "lijn"
  })
);