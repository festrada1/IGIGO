﻿define(
   ({
    timeout: "Limit czasu",
    highlightLocation: "Wyróżnij lokalizację",
    useTracking: "Uważaj na zmiany lokalizacji",
    warning: "Nieprawidłowe dane wejściowe"
  })
);