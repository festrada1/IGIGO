﻿define(
   ({
    _widgetLabel: "Başlık Denetleyici",
    signin: "Oturum Aç",
    signout: "Oturumu Kapat",
    about: "Hakkında",
    signInTo: "Şurada oturum aç",
    cantSignOutTip: "Bu işlev ön izleme modunda yok."
  })
);
