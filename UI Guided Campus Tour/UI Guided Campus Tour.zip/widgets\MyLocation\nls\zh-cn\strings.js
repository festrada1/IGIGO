﻿define(
   ({
    _widgetLabel: "我的位置",
    title: "查找我的位置",
    browserError: "此浏览器不支持地理定位。",
    failureFinding: "无法找到您的位置。请检查浏览器以确保已共享位置。"
  })
);