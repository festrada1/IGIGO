﻿define(
   ({
    unit: "Unidade",
    style: "Estilo",
    dual: "dual",
    english: "português",
    metric: "métrico",
    ruler: "régua",
    line: "linha"
  })
);