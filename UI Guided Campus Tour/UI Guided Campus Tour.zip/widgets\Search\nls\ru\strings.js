﻿define(
   ({
    _widgetLabel: "Поиск",
    searchResult: "Результаты поиска",
    showAllResults: "Показать результаты поиска для ",
    showAll: "Показать результаты поиска",
    more: "больше",
    untitled: "Нет заголовка"
  })
);