﻿define(
   ({
    timeout: "Timeout",
    highlightLocation: "Markera plats",
    useTracking: "Håll utkik efter platsändringar",
    warning: "Felaktiga indata"
  })
);