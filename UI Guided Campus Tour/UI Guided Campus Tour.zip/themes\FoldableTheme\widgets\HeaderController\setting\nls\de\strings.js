﻿define(
   ({
    group: "Name",
    openAll: "Alle im Bereich öffnen",
    dropDown: "In Dropdown-Menü anzeigen",
    noGroup: "Es wurde keine Widget-Gruppe festgelegt.",
    groupSetLabel: "Eigenschaften für Widget-Gruppen festlegen"
  })
);