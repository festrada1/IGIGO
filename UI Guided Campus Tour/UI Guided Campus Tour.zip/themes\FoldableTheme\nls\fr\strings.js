﻿define(
   ({
    _themeLabel: "Thème pliable",
    _layout_default: "Mise en page par défaut",
    _layout_layout1: "Mise en page 1"
  })
);