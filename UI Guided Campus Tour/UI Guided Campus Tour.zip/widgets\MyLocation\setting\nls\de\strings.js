﻿define(
   ({
    timeout: "Timeout",
    highlightLocation: "Position hervorheben",
    useTracking: "Positionsänderungen überwachen",
    warning: "Falsche Eingabe"
  })
);