﻿define(
   ({
    _widgetLabel: "Pesquisar",
    searchResult: "Pesquisar recultados",
    showAllResults: "Mostrar resultados de pesquisa para ",
    showAll: "Mostrar resultados de pesquisa",
    more: "mais",
    untitled: "Sem título"
  })
);