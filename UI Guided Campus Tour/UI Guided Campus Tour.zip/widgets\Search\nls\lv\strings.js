﻿define(
   ({
    _widgetLabel: "Meklēšana",
    searchResult: "Meklēšanas rezultāts",
    showAllResults: "Rādīt meklēšanas rezultātus vienumam ",
    showAll: "Rādīt meklēšanas rezultātus",
    more: "vairāk",
    untitled: "Bez nosaukuma"
  })
);