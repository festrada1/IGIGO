﻿define(
   ({
    unit: "Birim",
    style: "Stil",
    dual: "ikili",
    english: "İngilizce",
    metric: "metrik",
    ruler: "cetvel",
    line: "çizgi"
  })
);