﻿define(
   ({
    unit: "Ühik",
    style: "Stiil",
    dual: "duaalne",
    english: "inglise",
    metric: "meetermõõdustik",
    ruler: "joonlaud",
    line: "joon"
  })
);