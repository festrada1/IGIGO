﻿define(
   ({
    _widgetLabel: "比例尺"
  })
);