﻿define(
   ({
    _widgetLabel: "首頁按鈕"
  })
);