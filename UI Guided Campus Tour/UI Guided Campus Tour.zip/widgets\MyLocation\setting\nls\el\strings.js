﻿define(
   ({
    timeout: "Χρονικό όριο",
    highlightLocation: "Επισήμανση τοποθεσίας",
    useTracking: "Παρακολούθηση αλλαγών τοποθεσίας",
    warning: "Εσφαλμένη είσοδος"
  })
);