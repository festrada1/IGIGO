﻿define(
   ({
    _widgetLabel: "Suche",
    searchResult: "Suchergebnis",
    showAllResults: "Suchergebnisse anzeigen für ",
    showAll: "Suchergebnisse anzeigen",
    more: "mehr",
    untitled: "Ohne Titel"
  })
);