﻿define(
   ({
    unit: "Yksikkö",
    style: "Tyyli",
    dual: "molemmat",
    english: "englanti",
    metric: "metrinen",
    ruler: "viivain",
    line: "viiva"
  })
);