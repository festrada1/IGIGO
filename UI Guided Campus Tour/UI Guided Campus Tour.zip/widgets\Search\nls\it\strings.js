﻿define(
   ({
    _widgetLabel: "Ricerca",
    searchResult: "Risultato ricerca",
    showAllResults: "Mostra risultati ricerca per ",
    showAll: "Mostra risultati ricerca",
    more: "altro",
    untitled: "Senza titolo"
  })
);