﻿define(
   ({
    timeout: "Tidsavbrudd",
    highlightLocation: "Uthev lokasjon",
    useTracking: "Se etter lokasjonsendringer",
    warning: "Feil inndata"
  })
);