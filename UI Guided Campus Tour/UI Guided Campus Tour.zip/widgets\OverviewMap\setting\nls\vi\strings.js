﻿define(
   ({
    visible: "Hiển thị bản đồ toàn cảnh theo mặc định",
    minWidth: "Chiều rộng tối thiểu",
    minHeight: "Chiều cao tối thiểu",
    maxWidth: "Chiều rộng tối đa",
    maxHeight: "Chiều cao tối đa",
    minText: "Tối thiểu",
    maxText: "tối đa",
    attachText: "Chỉ định góc bản đồ đính kèm tiện ích này.",
    expandText: "Mở rộng tiện ích lúc ban đầu",
    topLeft: "Trên cùng Bên trái",
    topRight: "Trên cùng Bên phải",
    bottomLeft: "Dưới cùng Bên trái",
    bottomRight: "Dưới cùng Bên phải"
  })
);