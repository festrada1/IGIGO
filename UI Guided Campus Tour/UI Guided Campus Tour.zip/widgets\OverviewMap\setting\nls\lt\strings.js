﻿define(
   ({
    visible: "Rodyti apžvalgos žemėlapį pagal numatymą",
    minWidth: "Min. plotis",
    minHeight: "Min. aukštis",
    maxWidth: "Maks. plotis",
    maxHeight: "Maks. aukštis",
    minText: "Minimumas",
    maxText: "maksimumas",
    attachText: "Nurodykite, kuriame žemėlapio kampe talpinti šį valdiklį.",
    expandText: "Atverti valdiklį iš pradžių",
    topLeft: "Viršuje kairėje",
    topRight: "Viršuje dešinėje",
    bottomLeft: "Apačioje kairėje",
    bottomRight: "Apačioje dešinėje"
  })
);