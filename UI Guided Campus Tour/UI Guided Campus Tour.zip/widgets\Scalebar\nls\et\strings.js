﻿define(
   ({
    _widgetLabel: "Mõõtkava"
  })
);