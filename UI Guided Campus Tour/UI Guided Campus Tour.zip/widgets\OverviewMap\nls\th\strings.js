﻿define(
   ({
    _widgetLabel: "ภาพรวมของแผนที่"
  })
);