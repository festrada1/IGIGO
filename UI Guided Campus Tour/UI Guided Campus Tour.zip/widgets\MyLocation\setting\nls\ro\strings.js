﻿define(
   ({
    timeout: "Expirare",
    highlightLocation: "Evidenţiere locaţie",
    useTracking: "Monitorizare modificări locaţie",
    warning: "Intrare incorectă"
  })
);