﻿define(
   ({
    _widgetLabel: "Mans izvietojums",
    title: "Atrast manu izvietojumu",
    browserError: "Šī pārlūkprogramma neatbalsta ģeogrāfisko atrašanās vietu.",
    failureFinding: "Nevar atrast jūsu atrašanās vietu. Pārbaudiet pārlūkā, vai jūsu atrašanās vieta tiek kopīgota."
  })
);