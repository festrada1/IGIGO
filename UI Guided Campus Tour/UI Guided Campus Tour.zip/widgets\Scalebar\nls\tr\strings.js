﻿define(
   ({
    _widgetLabel: "Ölçek çubuğu"
  })
);