﻿define(
   ({
    _widgetLabel: "Søke",
    searchResult: "Søkeresultater",
    showAllResults: "Vis søkeresultater for ",
    showAll: "Vis søkeresultater",
    more: "mer",
    untitled: "Uten tittel"
  })
);