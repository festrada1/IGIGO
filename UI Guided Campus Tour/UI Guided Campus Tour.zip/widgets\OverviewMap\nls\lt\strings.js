﻿define(
   ({
    _widgetLabel: "Apžvalgos žemėlapis"
  })
);