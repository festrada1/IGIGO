﻿define(
   ({
    timeout: "Time-out",
    highlightLocation: "Locatie markeren",
    useTracking: "Let op locatiewijzigingen",
    warning: "Onjuiste invoer"
  })
);