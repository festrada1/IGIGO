﻿define(
   ({
    unit: "Jednostka",
    style: "Styl",
    dual: "podwójny",
    english: "angielski",
    metric: "metryczny",
    ruler: "linijka",
    line: "linia"
  })
);