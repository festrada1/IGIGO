﻿define(
   ({
    _widgetLabel: "Podziałka liniowa"
  })
);