﻿define(
   ({
    _widgetLabel: "Barra de Escala"
  })
);