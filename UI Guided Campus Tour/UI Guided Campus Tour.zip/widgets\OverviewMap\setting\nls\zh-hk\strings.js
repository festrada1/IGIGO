﻿define(
   ({
    visible: "顯示預設的總覽圖",
    minWidth: "最小寬度",
    minHeight: "最小高度",
    maxWidth: "最大寬度",
    maxHeight: "最大高度",
    minText: "最小值",
    maxText: "最大值",
    attachText: "指定要附加此 widget 的地圖角落。",
    expandText: "最初展開的 widget",
    topLeft: "左上",
    topRight: "右上",
    bottomLeft: "左下",
    bottomRight: "右下"
  })
);