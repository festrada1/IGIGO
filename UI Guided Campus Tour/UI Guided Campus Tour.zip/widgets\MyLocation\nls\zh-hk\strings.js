﻿define(
   ({
    _widgetLabel: "我的位置",
    title: "尋找我的位置",
    browserError: "此瀏覽器不支援地理定位。",
    failureFinding: "無法找到您的位置。請檢查瀏覽器以確定已共用位置。"
  })
);