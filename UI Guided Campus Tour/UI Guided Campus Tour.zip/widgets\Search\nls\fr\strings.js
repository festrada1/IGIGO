﻿define(
   ({
    _widgetLabel: "Rechercher",
    searchResult: "Résultat de la recherche",
    showAllResults: "Afficher les résultats de recherche pour ",
    showAll: "Afficher les résultats de recherche",
    more: "plus",
    untitled: "Sans titre"
  })
);