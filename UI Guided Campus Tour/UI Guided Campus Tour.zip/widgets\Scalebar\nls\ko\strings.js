﻿define(
   ({
    _widgetLabel: "축척 막대"
  })
);