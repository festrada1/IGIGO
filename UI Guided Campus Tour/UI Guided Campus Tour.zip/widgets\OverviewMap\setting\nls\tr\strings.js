﻿define(
   ({
    visible: "maksimize edici",
    minWidth: "Min Genişlik",
    minHeight: "Min Yükseklik",
    maxWidth: "Maks Genişlik",
    maxHeight: "Maks Yükseklik",
    minText: "Minimum",
    maxText: "maksimum",
    attachText: "Bu gerecin haritanın hangi köşesine iliştirileceğini belirtin.",
    expandText: "İlk olarak gereci genişlet",
    topLeft: "Üst Sol",
    topRight: "Üst Sağ",
    bottomLeft: "Alt Sol",
    bottomRight: "Alt Sağ"
  })
);