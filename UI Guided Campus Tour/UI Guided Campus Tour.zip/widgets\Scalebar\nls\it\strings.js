﻿define(
   ({
    _widgetLabel: "Barra della scala"
  })
);