﻿define(
   ({
    _widgetLabel: "Ovladač záhlaví",
    signin: "Přihlásit se",
    signout: "Odhlásit se",
    about: "O aplikaci",
    signInTo: "Přihlásit se do",
    cantSignOutTip: "Tato funkce není v režimu náhledu k dispozici."
  })
);
