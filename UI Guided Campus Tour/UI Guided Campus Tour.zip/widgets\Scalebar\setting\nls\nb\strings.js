﻿define(
   ({
    unit: "Enhet",
    style: "Stil",
    dual: "dobbel",
    english: "engelsk",
    metric: "metric",
    ruler: "linjal",
    line: "linje"
  })
);