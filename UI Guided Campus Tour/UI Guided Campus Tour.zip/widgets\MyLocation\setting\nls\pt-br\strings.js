﻿define(
   ({
    timeout: "Tempo Limite",
    highlightLocation: "Destacar local",
    useTracking: "Assista para alterações do local",
    warning: "Entrada incorreta"
  })
);