﻿define(
   ({
    timeout: "Timeout",
    highlightLocation: "Fremhæv sted",
    useTracking: "Se efter positionsændringer",
    warning: "Forkert input"
  })
);