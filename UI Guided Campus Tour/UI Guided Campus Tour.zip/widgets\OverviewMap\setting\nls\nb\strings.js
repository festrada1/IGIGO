﻿define(
   ({
    visible: "Vis oversiktskart som standard",
    minWidth: "Min. bredde",
    minHeight: "Min. høyde",
    maxWidth: "Maks. bredde",
    maxHeight: "Maks. høyde",
    minText: "Minimum",
    maxText: "maksimum",
    attachText: "Angi i hvilket hjørne av kartet denne widgeten skal legges til i.",
    expandText: "Utvid widgteten fra start",
    topLeft: "Øvre venstre",
    topRight: "Øvre høyre",
    bottomLeft: "Nedre venstre",
    bottomRight: "Nedre høyre"
  })
);