﻿define(
   ({
    _widgetLabel: "Vue générale"
  })
);