﻿define(
   ({
    timeout: "Timeout",
    highlightLocation: "Evidenzia posizione",
    useTracking: "Ricerca modifiche posizione",
    warning: "Input errato"
  })
);