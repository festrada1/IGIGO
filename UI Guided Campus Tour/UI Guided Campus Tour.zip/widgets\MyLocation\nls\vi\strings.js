﻿define(
   ({
    _widgetLabel: "Vị trí của tôi",
    title: "Tìm vị trí của tôi",
    browserError: "Vị trí địa lý không được hỗ trợ trong trình duyệt này.",
    failureFinding: "Không thể tìm thấy vị trí của bạn. Vui lòng kiểm tra trình duyệt của bạn để đảm bảo rằng vị trí của bạn được chia sẻ."
  })
);