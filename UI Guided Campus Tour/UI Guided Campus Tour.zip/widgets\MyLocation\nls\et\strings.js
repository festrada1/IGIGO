﻿define(
   ({
    _widgetLabel: "Minu asukoht",
    title: "Leia minu asukoht",
    browserError: "See brauser ei toeta asukoha määramist.",
    failureFinding: "Teie asukohta ei õnnestu leida. Kontrollige brauseri kaudu, kas Teie asukoht on jagatud."
  })
);