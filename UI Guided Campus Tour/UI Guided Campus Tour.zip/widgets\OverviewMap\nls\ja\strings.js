﻿define(
   ({
    _widgetLabel: "概観図"
  })
);