﻿define(
   ({
    visible: "Afişare implicită rezumat hartă",
    minWidth: "Lăţime minimă",
    minHeight: "Înălţime minimă",
    maxWidth: "Lăţime maximă",
    maxHeight: "Înălţime maximă",
    minText: "Minim",
    maxText: "maxim",
    attachText: "Specificaţi colţul hărţii la care se ataşează acest widget.",
    expandText: "Extindeţi iniţial widgetul",
    topLeft: "Stânga sus",
    topRight: "Dreapta sus",
    bottomLeft: "Stânga jos",
    bottomRight: "Dreapta jos"
  })
);