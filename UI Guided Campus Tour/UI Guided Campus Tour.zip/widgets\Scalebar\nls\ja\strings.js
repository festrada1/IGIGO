﻿define(
   ({
    _widgetLabel: "縮尺記号"
  })
);