﻿define(
   ({
    _widgetLabel: "Übersichtskarte"
  })
);