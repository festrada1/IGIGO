﻿define(
   ({
    _widgetLabel: "Meu Local",
    title: "Encontrar meu local",
    browserError: "A geolocalização não é suportada por este navegador.",
    failureFinding: "Não é possível encontrar seu local. Verifique seu navegador para garantir que seu local está compartilhado."
  })
);