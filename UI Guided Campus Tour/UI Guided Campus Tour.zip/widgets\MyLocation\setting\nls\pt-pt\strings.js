﻿define(
   ({
    timeout: "Timeout",
    highlightLocation: "Destacar local",
    useTracking: "Prestar atenção a mudanças de local",
    warning: "Entrada incorreta"
  })
);