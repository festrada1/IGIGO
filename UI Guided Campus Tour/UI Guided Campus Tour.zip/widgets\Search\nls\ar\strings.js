﻿define(
   ({
    _widgetLabel: "بحث",
    searchResult: "البحث عن النتائج",
    showAllResults: "عرض نتائج البحث ",
    showAll: "عرض نتائج البحث",
    more: "المزيد",
    untitled: "بلا عنوان"
  })
);