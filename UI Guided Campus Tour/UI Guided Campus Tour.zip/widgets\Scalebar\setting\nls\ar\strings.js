﻿define(
   ({
    unit: "وحدة",
    style: "نمط",
    dual: "ثنائي",
    english: "لغة إنجليزية",
    metric: "متري",
    ruler: "مسطرة",
    line: "خط"
  })
);