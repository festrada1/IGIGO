﻿define(
   ({
    _widgetLabel: "搜尋",
    searchResult: "搜尋結果",
    showAllResults: "顯示搜尋結果 ",
    showAll: "顯示搜尋結果",
    more: "更多",
    untitled: "無標題"
  })
);