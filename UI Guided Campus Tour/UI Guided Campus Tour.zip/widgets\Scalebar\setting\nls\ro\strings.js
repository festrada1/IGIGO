﻿define(
   ({
    unit: "Unitate",
    style: "Stil",
    dual: "dublu",
    english: "imperial",
    metric: "metric",
    ruler: "riglă",
    line: "linie"
  })
);