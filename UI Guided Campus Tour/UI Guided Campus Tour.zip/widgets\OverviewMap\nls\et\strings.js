﻿define(
   ({
    _widgetLabel: "Ülevaatekaart"
  })
);