﻿define(
   ({
    _widgetLabel: "Översiktskarta"
  })
);