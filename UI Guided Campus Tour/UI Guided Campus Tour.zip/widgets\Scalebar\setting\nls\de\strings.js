﻿define(
   ({
    unit: "Einheit",
    style: "Style",
    dual: "dual",
    english: "Englisch",
    metric: "Metrisch",
    ruler: "Lineal",
    line: "Linie"
  })
);