﻿define(
   ({
    _widgetLabel: "خريطة النظرة العامة"
  })
);