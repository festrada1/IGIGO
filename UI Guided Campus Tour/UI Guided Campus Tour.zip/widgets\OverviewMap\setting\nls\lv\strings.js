﻿define(
   ({
    visible: "Pēc noklusējuma rādīt pārskata karti",
    minWidth: "Min. platums",
    minHeight: "Min. augstums",
    maxWidth: "Maks. platums",
    maxHeight: "Maks. augstums",
    minText: "Minimums",
    maxText: "maksimums",
    attachText: "Norādiet, kuram kartes stūrim pievienot šo logrīku.",
    expandText: "Sākotnēji izvērst logrīku",
    topLeft: "Augšējā kreisajā stūrī",
    topRight: "Augšējā labajā stūrī",
    bottomLeft: "Apakšējā kreisajā stūrī",
    bottomRight: "Apakšējā labajā stūrī"
  })
);