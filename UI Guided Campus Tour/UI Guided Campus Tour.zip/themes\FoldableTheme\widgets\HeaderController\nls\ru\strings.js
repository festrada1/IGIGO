﻿define(
   ({
    _widgetLabel: "Контроллер заголовка",
    signin: "Войти",
    signout: "Выйти",
    about: "О",
    signInTo: "Войти в",
    cantSignOutTip: "Эта функция недоступна в режиме предварительного просмотра."
  })
);
