﻿define(
   ({
    _widgetLabel: "Maßstabsleiste"
  })
);