﻿define(
   ({
    _widgetLabel: "Mappa d\'insieme"
  })
);