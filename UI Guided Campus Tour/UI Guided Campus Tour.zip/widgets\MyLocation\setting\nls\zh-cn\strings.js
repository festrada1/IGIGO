﻿define(
   ({
    timeout: "超时",
    highlightLocation: "高亮显示位置",
    useTracking: "查看位置更改",
    warning: "输入不正确"
  })
);