﻿define(
   ({
    _widgetLabel: "Khung tỷ lệ"
  })
);