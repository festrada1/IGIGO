﻿define(
   ({
    visible: "Visa översiktskarta som standard",
    minWidth: "Minsta bredd",
    minHeight: "Minsta höjd",
    maxWidth: "Max bredd",
    maxHeight: "Max höjd",
    minText: "Minimum",
    maxText: "max",
    attachText: "Ange i vilket hörn av kartan som widgeten ska fästas.",
    expandText: "Börja med att expandera widgeten",
    topLeft: "Överst till vänster",
    topRight: "Överst till höger",
    bottomLeft: "Nederst till vänster",
    bottomRight: "Nederst till höger"
  })
);