﻿define(
   ({
    unit: "單位",
    style: "樣式",
    dual: "雙重",
    english: "英語",
    metric: "公制",
    ruler: "標尺",
    line: "線"
  })
);