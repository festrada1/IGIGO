﻿define(
   ({
    visible: "Zobrazovat mapu přehledu jako výchozí",
    minWidth: "Minimální šířka",
    minHeight: "Minimální výška",
    maxWidth: "Maximální šířka",
    maxHeight: "Maximální výška",
    minText: "Minimum",
    maxText: "Maximum",
    attachText: "Určete, do kterého rohu mapy chcete tento widget připojit.",
    expandText: "Rozšířit widget po přidání",
    topLeft: "Levý horní roh",
    topRight: "Pravý horní roh",
    bottomLeft: "Levý dolní roh",
    bottomRight: "Pravý dolní roh"
  })
);