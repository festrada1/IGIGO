﻿define(
   ({
    _widgetLabel: "Skalas_josla"
  })
);