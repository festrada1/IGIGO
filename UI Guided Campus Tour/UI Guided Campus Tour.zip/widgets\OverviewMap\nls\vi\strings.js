﻿define(
   ({
    _widgetLabel: "Bản đồ Toàn cảnh"
  })
);