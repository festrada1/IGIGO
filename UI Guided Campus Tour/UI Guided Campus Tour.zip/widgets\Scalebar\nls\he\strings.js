﻿define(
   ({
    _widgetLabel: "סרגל קנה מידה"
  })
);