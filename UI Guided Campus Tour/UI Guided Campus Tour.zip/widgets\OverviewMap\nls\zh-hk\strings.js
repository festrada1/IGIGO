﻿define(
   ({
    _widgetLabel: "總覽圖"
  })
);