﻿define(
   ({
    _widgetLabel: "Oversiktskart"
  })
);