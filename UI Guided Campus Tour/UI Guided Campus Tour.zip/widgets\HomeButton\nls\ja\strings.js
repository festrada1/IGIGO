﻿define(
   ({
    _widgetLabel: "ホーム ボタン"
  })
);