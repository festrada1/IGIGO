﻿define(
   ({
    _widgetLabel: "Mon emplacement",
    title: "Rechercher mon emplacement",
    browserError: "La géolocalisation n’est pas prise en charge par ce navigateur.",
    failureFinding: "Votre emplacement est introuvable. Vérifiez dans votre navigateur que votre emplacement est partagé."
  })
);