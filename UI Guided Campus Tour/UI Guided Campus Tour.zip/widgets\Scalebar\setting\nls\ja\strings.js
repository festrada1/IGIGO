﻿define(
   ({
    unit: "単位",
    style: "スタイル",
    dual: "デュアル",
    english: "英語",
    metric: "メートル法",
    ruler: "ルーラー",
    line: "ライン"
  })
);