﻿define(
   ({
    timeout: "Vaheaeg",
    highlightLocation: "Tõsta asukoht esile",
    useTracking: "Jälgi asukohamuutusi",
    warning: "Vale sisend"
  })
);