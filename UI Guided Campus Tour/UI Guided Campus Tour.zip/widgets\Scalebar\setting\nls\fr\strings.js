﻿define(
   ({
    unit: "Unités",
    style: "Style",
    dual: "double",
    english: "anglaises",
    metric: "métriques",
    ruler: "règle",
    line: "ligne"
  })
);