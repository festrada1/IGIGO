﻿define(
   ({
    unit: "Đơn vị",
    style: "Kiểu",
    dual: "kép",
    english: "tiếng anh",
    metric: "hệ mét",
    ruler: "thước",
    line: "đường"
  })
);