﻿define(
   ({
    _widgetLabel: "Zoeken",
    searchResult: "Search Results",
    showAllResults: "Toon zoekresultaten voor ",
    showAll: "Toon zoekresultaten",
    more: "meer",
    untitled: "Naamloos"
  })
);