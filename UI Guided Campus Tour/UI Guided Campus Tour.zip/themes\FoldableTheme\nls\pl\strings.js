﻿define(
   ({
    _themeLabel: "Motyw Składane",
    _layout_default: "Układ domyślny",
    _layout_layout1: "Układ 1"
  })
);