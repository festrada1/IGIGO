﻿define(
   ({
    _widgetLabel: "Etsi",
    searchResult: "Hakutulos",
    showAllResults: "Näytä hakutulokset haulle ",
    showAll: "Näytä hakutulokset",
    more: "lisää",
    untitled: "Nimetön"
  })
);