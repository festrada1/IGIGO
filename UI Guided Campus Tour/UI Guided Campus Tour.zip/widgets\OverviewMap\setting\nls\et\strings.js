﻿define(
   ({
    visible: "Kuva ülevaatekaarti vaikimisi",
    minWidth: "Min laius",
    minHeight: "Min kõrgus",
    maxWidth: "Max laius",
    maxHeight: "Max kõrgus",
    minText: "Miinimum",
    maxText: "Maksimum",
    attachText: "Määrake, millisesse kaardi nurka see vidin paigutada.",
    expandText: "Laienda vidin alustamisel",
    topLeft: "Üles vasakule",
    topRight: "Üles paremale",
    bottomLeft: "Alla vasakule",
    bottomRight: "Alla paremale"
  })
);