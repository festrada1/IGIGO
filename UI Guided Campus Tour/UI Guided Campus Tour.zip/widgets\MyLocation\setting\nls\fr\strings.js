﻿define(
   ({
    timeout: "Expiration",
    highlightLocation: "Mettre en surbrillance l’emplacement",
    useTracking: "Observer les modifications d\'emplacement",
    warning: "Entrée incorrecte"
  })
);