﻿define(
   ({
    _widgetLabel: "Масштабная линейка"
  })
);