﻿define(
   ({
    _widgetLabel: "Căutare",
    searchResult: "Rezultat căutare",
    showAllResults: "Afişare rezultate căutare pentru ",
    showAll: "Afişare rezultate căutare",
    more: "mai mult",
    untitled: "Fără titlu"
  })
);