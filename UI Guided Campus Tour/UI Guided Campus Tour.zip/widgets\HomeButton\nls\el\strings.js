﻿define(
   ({
    _widgetLabel: "Αρχική σελίδα"
  })
);