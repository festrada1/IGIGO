﻿define(
   ({
    _widgetLabel: "ค้นหา",
    searchResult: "ผลลัพธ์การค้นหา",
    showAllResults: "แสดงผลลัพธ์การค้นหาสำหรับ ",
    showAll: "แสดงผลลัพธ์การค้นหา",
    more: "เพิ่มเติม",
    untitled: "ไม่มีชื่อเรื่อง"
  })
);