﻿define(
   ({
    group: "Nimi",
    openAll: "Avaa kaikki paneelissa",
    dropDown: "Näytä pudotusvalikossa",
    noGroup: "Pienoisohjelmaryhmää ei ole asetettu.",
    groupSetLabel: "Aseta pienoisohjelmaryhmien ominaisuudet"
  })
);