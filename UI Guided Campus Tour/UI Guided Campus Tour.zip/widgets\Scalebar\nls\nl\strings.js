﻿define(
   ({
    _widgetLabel: "Schaalbalk"
  })
);