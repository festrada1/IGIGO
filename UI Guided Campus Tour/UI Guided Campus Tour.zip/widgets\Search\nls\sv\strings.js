﻿define(
   ({
    _widgetLabel: "Sök",
    searchResult: "Sökresultat",
    showAllResults: "Visa sökresultat för ",
    showAll: "Visa sökresultat",
    more: "fler",
    untitled: "Namnlös"
  })
);