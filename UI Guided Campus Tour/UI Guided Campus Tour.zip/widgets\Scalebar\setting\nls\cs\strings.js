﻿define(
   ({
    unit: "Jednotka",
    style: "Styl",
    dual: "dvojí",
    english: "anglické",
    metric: "metrické",
    ruler: "pravítko",
    line: "linie"
  })
);