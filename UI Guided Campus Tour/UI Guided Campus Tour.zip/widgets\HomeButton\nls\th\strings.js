﻿define(
   ({
    _widgetLabel: "ปุ่มหน้าหลัก"
  })
);