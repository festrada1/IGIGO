﻿define(
   ({
    _widgetLabel: "Vista Geral do Mapa"
  })
);