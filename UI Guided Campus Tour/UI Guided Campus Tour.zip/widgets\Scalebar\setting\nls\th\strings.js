﻿define(
   ({
    unit: "หน่วย",
    style: "สไตล์",
    dual: "คู่",
    english: "อังกฤษ",
    metric: "เมทริกซ์",
    ruler: "ไม้บรรทัด",
    line: "เส้น"
  })
);