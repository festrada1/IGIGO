﻿define(
   ({
    timeout: "Aikakatkaisu",
    highlightLocation: "Korosta sijainti",
    useTracking: "Tarkkaile sijaintimuutoksia",
    warning: "Virheellinen lähtöaineisto"
  })
);