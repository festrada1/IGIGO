﻿define(
   ({
    _widgetLabel: "زر البداية"
  })
);