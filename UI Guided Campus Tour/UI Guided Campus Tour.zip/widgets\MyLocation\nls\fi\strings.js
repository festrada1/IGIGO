﻿define(
   ({
    _widgetLabel: "Sijaintini",
    title: "Etsi sijaintini",
    browserError: "Tämä selain ei tue geosijaintia.",
    failureFinding: "Sijaintiasi ei löydy. Tarkista selaimestasi, että sijaintisi on jaettu."
  })
);