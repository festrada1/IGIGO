﻿define(
   ({
    visible: "Mostra mappa panoramica per impostazione predefinita",
    minWidth: "Larghezza min",
    minHeight: "Altezza min",
    maxWidth: "Larghezza max",
    maxHeight: "Altezza max",
    minText: "Minimo",
    maxText: "massimo",
    attachText: "Specificare l\'angolo della mappa a cui associare il widget.",
    expandText: "Espandere innanzitutto il widget",
    topLeft: "Superiore sinistro",
    topRight: "Superiore destro",
    bottomLeft: "Inferiore sinistro",
    bottomRight: "Inferiore destro"
  })
);