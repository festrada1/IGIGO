﻿define(
   ({
    _widgetLabel: "現在の場所",
    title: "現在の場所を検索",
    browserError: "このブラウザーでは Geolocation はサポートされていません。",
    failureFinding: "現在位置が見つかりません。ブラウザーで現在地が共有されているか確認してください。"
  })
);