﻿define(
   ({
    timeout: "Thời gian chờ",
    highlightLocation: "Vị trí nổi bật",
    useTracking: "Theo dõi các thay đổi vị trí",
    warning: "Đầu vào không đúng"
  })
);