﻿define(
   ({
    _widgetLabel: "חפש",
    searchResult: "תוצאות חיפוש",
    showAllResults: "הצג תוצאות חיפוש עבור ",
    showAll: "הצג תוצאות חיפוש",
    more: "עוד",
    untitled: "ללא שם"
  })
);