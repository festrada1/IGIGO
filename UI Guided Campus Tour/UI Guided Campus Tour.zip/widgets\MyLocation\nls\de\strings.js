﻿define(
   ({
    _widgetLabel: "Eigene Position",
    title: "Eigenen Standort suchen",
    browserError: "Geolocation wird von diesem Browser nicht unterstützt.",
    failureFinding: "Ihre Position kann nicht gefunden werden. Überprüfen Sie Ihren Browser, um sicherzustellen, dass Ihre Position freigegeben wurde."
  })
);