﻿define(
   ({
    timeout: "หมดเวลา",
    highlightLocation: "ตำแหน่งที่โดดเด่น",
    useTracking: "ดูสำหรับการเปลี่ยนตำแหน่ง",
    warning: "ข้อมูลนำเข้าไม่ถูกต้อง"
  })
);