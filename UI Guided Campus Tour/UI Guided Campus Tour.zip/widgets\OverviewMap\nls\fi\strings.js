﻿define(
   ({
    _widgetLabel: "Yleiskatsauskartta"
  })
);