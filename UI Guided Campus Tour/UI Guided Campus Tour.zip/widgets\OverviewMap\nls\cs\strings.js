﻿define(
   ({
    _widgetLabel: "Přehledová mapa"
  })
);