﻿define(
   ({
    visible: "显示默认的总览图",
    minWidth: "最小宽度",
    minHeight: "最小高度",
    maxWidth: "最大宽度",
    maxHeight: "最大高度",
    minText: "最小值",
    maxText: "最大值",
    attachText: "指定要在哪个地图拐角附加此微件。",
    expandText: "最初展开的微件",
    topLeft: "左上",
    topRight: "右上",
    bottomLeft: "左下",
    bottomRight: "右下"
  })
);