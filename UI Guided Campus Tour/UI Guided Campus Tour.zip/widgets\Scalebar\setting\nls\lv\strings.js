﻿define(
   ({
    unit: "Vienība",
    style: "Stils",
    dual: "dubults",
    english: "angļu",
    metric: "metriska",
    ruler: "lineāls",
    line: "līnija"
  })
);