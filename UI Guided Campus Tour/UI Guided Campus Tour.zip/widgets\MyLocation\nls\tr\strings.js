﻿define(
   ({
    _widgetLabel: "Konumum",
    title: "Konumumu bul",
    browserError: "Coğrafi konum bu tarayıcı tarafından desteklenmiyor.",
    failureFinding: "Konumunuz bulunamıyor. Tarayıcınızı kontrol ederek konumunuzun paylaşıldığından emin olun."
  })
);