﻿define(
   ({
    timeout: "タイムアウト",
    highlightLocation: "現在位置のハイライト表示",
    useTracking: "位置の変更を監視",
    warning: "不正な入力"
  })
);