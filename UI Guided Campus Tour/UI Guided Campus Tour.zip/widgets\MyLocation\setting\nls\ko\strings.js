﻿define(
   ({
    timeout: "제한 시간",
    highlightLocation: "위치 강조",
    useTracking: "위치 변경 사항 보기",
    warning: "잘못된 입력"
  })
);