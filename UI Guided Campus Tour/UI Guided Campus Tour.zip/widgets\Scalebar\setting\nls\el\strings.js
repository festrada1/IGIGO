﻿define(
   ({
    unit: "Μονάδα",
    style: "Στυλ",
    dual: "διπλό",
    english: "αγγλικό",
    metric: "μετρικό",
    ruler: "χάρακας",
    line: "γραμμή"
  })
);