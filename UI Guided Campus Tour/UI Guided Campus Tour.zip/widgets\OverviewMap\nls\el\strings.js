﻿define(
   ({
    _widgetLabel: "Χάρτης επισκόπησης"
  })
);