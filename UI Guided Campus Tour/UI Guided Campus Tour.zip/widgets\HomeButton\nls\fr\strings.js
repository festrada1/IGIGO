﻿define(
   ({
    _widgetLabel: "Bouton d’accueil"
  })
);