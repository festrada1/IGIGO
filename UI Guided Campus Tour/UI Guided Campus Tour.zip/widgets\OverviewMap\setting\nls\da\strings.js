﻿define(
   ({
    visible: "Vis oversigtskort som standard",
    minWidth: "Minmumbredde",
    minHeight: "Minimumhøjde",
    maxWidth: "Maksimumbredde",
    maxHeight: "Maksimumhøjde",
    minText: "Minimum",
    maxText: "maksimum",
    attachText: "Angiv, i hvilket hjørne af kortet denne widget skal tilknyttes.",
    expandText: "Udvid først widget'en",
    topLeft: "Øverst til venstre",
    topRight: "Øverst til højre",
    bottomLeft: "Nederst til venstre",
    bottomRight: "Nederst til højre"
  })
);