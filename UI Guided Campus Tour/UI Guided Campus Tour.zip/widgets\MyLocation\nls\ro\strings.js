﻿define(
   ({
    _widgetLabel: "Locaţia mea",
    title: "Găsire locaţie proprie",
    browserError: "Geolocaţia nu este suportată de acest browser.",
    failureFinding: "Locaţia dvs. nu poate fi găsită. Verificaţi browserul pentru a vă asigura că locaţia este partajată."
  })
);