﻿define(
   ({
    _widgetLabel: "Overzichtskaart"
  })
);