﻿define(
   ({
    _widgetLabel: "Szukaj",
    searchResult: "Search Results",
    showAllResults: "Wyświetl wyniki wyszukiwania dla ",
    showAll: "Wyświetl wyniki wyszukiwania",
    more: "więcej",
    untitled: "Brak tytułu"
  })
);