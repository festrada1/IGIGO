﻿define(
   ({
    _widgetLabel: "Moja lokalizacja",
    title: "Znajdź moją lokalizację",
    browserError: "Przeglądarka nie obsługuje geolokalizacji.",
    failureFinding: "Nie można odnaleźć Twojej lokalizacji. Sprawdź ustawienia przeglądarki i upewnij się, że Twoja lokalizacja została udostępniona."
  })
);