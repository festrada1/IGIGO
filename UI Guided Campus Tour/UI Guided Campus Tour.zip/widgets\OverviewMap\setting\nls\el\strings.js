﻿define(
   ({
    visible: "Εμφάνιση χάρτη αναφοράς εξ' ορισμού",
    minWidth: "Ελάχ. πλάτος",
    minHeight: "Ελάχ. ύψος",
    maxWidth: "Μέγ. πλάτος",
    maxHeight: "Μέγ. ύψος",
    minText: "Ελάχιστο",
    maxText: "μέγιστο",
    attachText: "Καθορίστε σε ποια γωνία του χάρτη θα επισυναφθεί αυτό το widget.",
    expandText: "Το widget να είναι αρχικά ανοιχτό",
    topLeft: "Πάνω αριστερά",
    topRight: "Πάνω δεξιά",
    bottomLeft: "Κάτω αριστερά",
    bottomRight: "Κάτω δεξιά"
  })
);