﻿define(
   ({
    timeout: "Zaman aşımı",
    highlightLocation: "Konumu vurgula",
    useTracking: "Konum değişikliklerini izle",
    warning: "Hatalı girdi"
  })
);