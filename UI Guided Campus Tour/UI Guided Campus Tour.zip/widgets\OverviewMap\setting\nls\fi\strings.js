﻿define(
   ({
    visible: "Näytä oletusarvoisesti yleiskatsauskartta",
    minWidth: "Minimileveys",
    minHeight: "Minimikorkeus",
    maxWidth: "Maksimileveys",
    maxHeight: "Maksimikorkeus",
    minText: "Minimi",
    maxText: "Maksimi",
    attachText: "Määritä kartan kulma, johon tämä pienoisohjelma liitetään.",
    expandText: "Laajenna pienoisohjelma aluksi",
    topLeft: "Ylä vasen",
    topRight: "Ylä oikea",
    bottomLeft: "Ala vasen",
    bottomRight: "Ala oikea"
  })
);