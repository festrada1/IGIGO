﻿define(
   ({
    _widgetLabel: "Grafické měřítko"
  })
);