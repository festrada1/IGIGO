﻿define(
   ({
    _widgetLabel: "Barre d’échelle"
  })
);