﻿define(
   ({
    _widgetLabel: "Moje poloha",
    title: "Najdi moji polohu",
    browserError: "Tento prohlížeč nepodporuje geolokaci.",
    failureFinding: "Vaši polohu nelze nalézt. Zkontrolujte, zda je prohlížeč nastaven tak, aby sdílel vaši polohu."
  })
);