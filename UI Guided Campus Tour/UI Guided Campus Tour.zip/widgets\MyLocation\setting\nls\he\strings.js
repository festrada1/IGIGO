﻿define(
   ({
    timeout: "זמן מוקצב",
    highlightLocation: "הדגש מיקום",
    useTracking: "שים לב לשינויים במיקום",
    warning: "קלט לא תקין"
  })
);