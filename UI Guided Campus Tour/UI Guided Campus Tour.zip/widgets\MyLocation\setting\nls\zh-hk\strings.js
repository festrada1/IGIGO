﻿define(
   ({
    timeout: "逾時",
    highlightLocation: "突顯位置",
    useTracking: "檢視位置更改",
    warning: "輸入不正確"
  })
);