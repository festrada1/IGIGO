﻿define(
   ({
    _widgetLabel: "Bară de scară"
  })
);