﻿define(
   ({
    _widgetLabel: "Hartă de prezentare generală"
  })
);