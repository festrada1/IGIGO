﻿define(
   ({
    _widgetLabel: "Pārskata karte"
  })
);