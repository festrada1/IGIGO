﻿define(
   ({
    visible: "デフォルトで概観図を表示",
    minWidth: "最小幅",
    minHeight: "最小高さ",
    maxWidth: "最大幅",
    maxHeight: "最大高さ",
    minText: "最小",
    maxText: "最大",
    attachText: "このウィジェットを配置する場所を指定します。",
    expandText: "初期画面よりウィジェットを表示",
    topLeft: "左上",
    topRight: "右上",
    bottomLeft: "左下",
    bottomRight: "右下"
  })
);