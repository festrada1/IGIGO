﻿define(
   ({
    _widgetLabel: "Coördinaat",
    hintMessage: "Klik op de kaart om de coördinaten te krijgen",
    defaultLabel: "Standaard",
    realtimeLabel: "Beweeg de muis om de coördinaten te verkrijgen",
    computing: "Bezig met berekenen...",
    latitudeLabel: "Breedtegraad",
    longitudeLabel: "Lengtegraad",
    loading: "laden...",
    enableClick: "Klik om, coördinaten te krijgen bij het klikken op de kaart, in te schakelen",
    disableClick: "Klik om, coördinaten te krijgen bij het klikken op de kaart, uit te schakelen",

    Default: "Standaard",
    Inches: "Inch",
    Foot: "Voet",
    Yards: "Yard",
    Miles: "Mijl",
    Nautical_Miles: "Zeemijl",
    Millimeters: "Millimeter",
    Centimeters: "Centimeter",
    Meter: "Meter",
    Kilometers: "Kilometer",
    Decimeters: "Decimeter",
    Decimal_Degrees: "Graden",
    Degree_Minutes_Seconds: "Graden minuten seconden",
    MGRS: "MGRS",
    USNG: "USNG"
  })
);
