﻿define(
   ({
    _widgetLabel: "Обзорная карта"
  })
);