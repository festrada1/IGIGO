﻿define(
   ({
    visible: "Exibir mapa de vista geral por defeito",
    minWidth: "Largura Mínima",
    minHeight: "Altura Mínima",
    maxWidth: "Largura Máxima",
    maxHeight: "Altura Máxima",
    minText: "Mínimo",
    maxText: "máximo",
    attachText: "Especifique o canto do mapa no qual este widget será anexado.",
    expandText: "Expandir o widget inicialmente",
    topLeft: "Superior Esquerdo",
    topRight: "Superior Direito",
    bottomLeft: "Inferior Esquerdo",
    bottomRight: "Inferior Direito"
  })
);