﻿define(
   ({
    _widgetLabel: "Rubrikhanterare",
    signin: "Logga in",
    signout: "Logga ut",
    about: "Om",
    signInTo: "Logga in på",
    cantSignOutTip: "Denna funktion är inte tillgänglig i förhandsgranskningsläge."
  })
);
