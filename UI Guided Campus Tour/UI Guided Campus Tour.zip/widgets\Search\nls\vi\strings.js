﻿define(
   ({
    _widgetLabel: "Tìm kiếm",
    searchResult: "Kết quả tìm kiếm",
    showAllResults: "Hiển thị kết quả tìm kiếm cho ",
    showAll: "Hiển thị kết quả tìm kiếm",
    more: "khác",
    untitled: "Chưa có tiêu đề"
  })
);