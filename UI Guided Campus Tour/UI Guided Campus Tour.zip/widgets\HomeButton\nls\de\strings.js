﻿define(
   ({
    _widgetLabel: "Schaltfläche \"Standardausdehnung\""
  })
);