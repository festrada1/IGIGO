﻿define(
   ({
    _widgetLabel: "개요보기 맵"
  })
);