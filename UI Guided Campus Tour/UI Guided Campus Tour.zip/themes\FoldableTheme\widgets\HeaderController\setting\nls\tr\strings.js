﻿define(
   ({
    group: "Ad",
    openAll: "Tümünü Panoda Aç",
    dropDown: "Açılır Menüde Göster",
    noGroup: "Ayarlanmış araç grubu yok.",
    groupSetLabel: "Araç grubu özelliklerini ayarla"
  })
);