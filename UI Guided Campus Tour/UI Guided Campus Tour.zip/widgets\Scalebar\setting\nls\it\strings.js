﻿define(
   ({
    unit: "Unità",
    style: "Stile",
    dual: "doppio",
    english: "inglese",
    metric: "metrico",
    ruler: "righello",
    line: "linea"
  })
);