﻿define(
   ({
    _widgetLabel: "Søg",
    searchResult: "Søgeresultater",
    showAllResults: "Vis søgeresultater for ",
    showAll: "Vis søgeresultater",
    more: "mere",
    untitled: "Untitled"
  })
);