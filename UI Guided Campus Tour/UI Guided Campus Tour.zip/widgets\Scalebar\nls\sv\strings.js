﻿define(
   ({
    _widgetLabel: "Skalfält"
  })
);