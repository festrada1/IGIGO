﻿define(
   ({
    unit: "Vienetai",
    style: "Stilius",
    dual: "abu",
    english: "angliški",
    metric: "metriniai",
    ruler: "liniuotė",
    line: "linija"
  })
);