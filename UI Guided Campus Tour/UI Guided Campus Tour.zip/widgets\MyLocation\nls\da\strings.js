﻿define(
   ({
    _widgetLabel: "Min position",
    title: "Find min placering",
    browserError: "Denne browser understøtter ikke geoplaceringer.",
    failureFinding: "Din placering kan ikke findes. Tjek din browser for at sikre, at din placering deles."
  })
);