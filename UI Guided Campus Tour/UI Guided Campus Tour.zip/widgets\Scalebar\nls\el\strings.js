﻿define(
   ({
    _widgetLabel: "Μπάρα κλίμακας"
  })
);