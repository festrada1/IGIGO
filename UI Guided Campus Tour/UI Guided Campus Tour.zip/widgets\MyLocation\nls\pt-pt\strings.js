﻿define(
   ({
    _widgetLabel: "Meu Local",
    title: "Encontrar meu local",
    browserError: "A Geolocalização não é suportada por este navegador.",
    failureFinding: "Não é possível encontrar a sua localização. Por favor confirme no seu browser que a sua localização está a ser partilhada."
  })
);