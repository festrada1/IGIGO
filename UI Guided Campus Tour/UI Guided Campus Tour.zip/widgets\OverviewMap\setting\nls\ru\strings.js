﻿define(
   ({
    visible: "Показывать обзорную карту по умолчанию",
    minWidth: "Мин. ширина",
    minHeight: "Мин. высота",
    maxWidth: "Макс. ширина",
    maxHeight: "Макс. высота",
    minText: "Минимум",
    maxText: "максимум",
    attachText: "Выберите угол карты, куда закрепить виджет.",
    expandText: "Открыть при запуске",
    topLeft: "Верхний левый",
    topRight: "Верхний правый",
    bottomLeft: "Нижний левый",
    bottomRight: "Нижний правый"
  })
);