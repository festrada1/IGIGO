﻿define(
   ({
    visible: "기본 설정에 따라 개요보기 맵 표시",
    minWidth: "최소 너비",
    minHeight: "최소 높이",
    maxWidth: "최대 너비",
    maxHeight: "최대 높이",
    minText: "최소",
    maxText: "최대",
    attachText: "이 위젯을 첨부할 맵의 모서리를 지정합니다.",
    expandText: "초기에 위젯 확장",
    topLeft: "왼쪽 상단",
    topRight: "오른쪽 상단",
    bottomLeft: "왼쪽 하단",
    bottomRight: "오른쪽 하단"
  })
);