﻿define(
   ({
    visible: "Übersichtskarte standardmäßig anzeigen",
    minWidth: "Minimale Breite",
    minHeight: "Minimale Höhe",
    maxWidth: "Maximale Breite",
    maxHeight: "Maximale Höhe",
    minText: "Minimum",
    maxText: "Maximum",
    attachText: "Legen Sie fest, an welcher Ecke der Karte dieses Widget angefügt werden soll.",
    expandText: "Zuerst das Widget erweitern",
    topLeft: "Links oben",
    topRight: "Rechts oben",
    bottomLeft: "Links unten",
    bottomRight: "Rechts unten"
  })
);