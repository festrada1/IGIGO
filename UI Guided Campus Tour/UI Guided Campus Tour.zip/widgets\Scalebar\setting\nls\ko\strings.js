﻿define(
   ({
    unit: "단위",
    style: "스타일",
    dual: "이중",
    english: "한국어",
    metric: "미터법",
    ruler: "눈금자",
    line: "라인"
  })
);