﻿define(
   ({
    _widgetLabel: "målestokklinjal"
  })
);