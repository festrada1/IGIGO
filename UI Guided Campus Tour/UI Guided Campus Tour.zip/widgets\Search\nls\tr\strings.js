﻿define(
   ({
    _widgetLabel: "Ara",
    searchResult: "Sonuç ara",
    showAllResults: "Şunun için sonuçları göster: ",
    showAll: "Arama sonuçlarını göster",
    more: "diğer",
    untitled: "Adsız"
  })
);