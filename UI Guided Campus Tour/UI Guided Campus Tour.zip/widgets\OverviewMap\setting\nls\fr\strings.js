﻿define(
   ({
    visible: "Afficher la vue générale par défaut",
    minWidth: "Largeur min.",
    minHeight: "Hauteur min.",
    maxWidth: "Largeur max.",
    maxHeight: "Hauteur max.",
    minText: "Minimum",
    maxText: "Maximum",
    attachText: "Spécifiez la position",
    expandText: "Ouvert au démarrage",
    topLeft: "En haut à gauche",
    topRight: "En haut à droite",
    bottomLeft: "En bas à gauche",
    bottomRight: "En bas à droite"
  })
);