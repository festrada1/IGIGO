﻿define(
   ({
    _widgetLabel: "شريط المقياس"
  })
);