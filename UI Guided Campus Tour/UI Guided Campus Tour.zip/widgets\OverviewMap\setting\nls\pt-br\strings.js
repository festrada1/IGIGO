﻿define(
   ({
    visible: "Mostrar mapa de visão geral por padrão",
    minWidth: "Largura Mín.",
    minHeight: "Altura Mín.",
    maxWidth: "Largura Máx.",
    maxHeight: "Altura Máx.",
    minText: "Mínimo",
    maxText: "Máximo",
    attachText: "Especifica qual canto do mapa anexar este widget.",
    expandText: "Expandir inicialmente o widget",
    topLeft: "Superior Esquerdo",
    topRight: "Superior Direito",
    bottomLeft: "Inferior Esquerdo",
    bottomRight: "Inferior Direito"
  })
);