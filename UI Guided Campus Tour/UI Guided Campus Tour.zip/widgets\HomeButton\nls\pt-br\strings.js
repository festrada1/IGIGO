﻿define(
   ({
    _widgetLabel: "Botão da Página Inicial"
  })
);