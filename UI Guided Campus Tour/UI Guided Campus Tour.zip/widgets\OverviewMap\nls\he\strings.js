﻿define(
   ({
    _widgetLabel: "מפת התמצאות"
  })
);