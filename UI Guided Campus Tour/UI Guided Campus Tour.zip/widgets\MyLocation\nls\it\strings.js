﻿define(
   ({
    _widgetLabel: "Posizione",
    title: "Trova posizione personale",
    browserError: "Geolocalizzazione non supportata dal browser in uso.",
    failureFinding: "Impossibile trovare la posizione. Controllare il browser per verificare che la posizione sia condivisa."
  })
);