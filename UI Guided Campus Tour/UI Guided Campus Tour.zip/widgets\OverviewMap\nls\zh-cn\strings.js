﻿define(
   ({
    _widgetLabel: "总览图"
  })
);