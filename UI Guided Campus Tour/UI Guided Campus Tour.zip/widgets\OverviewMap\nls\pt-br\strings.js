﻿define(
   ({
    _widgetLabel: "Mapa de Visão Geral"
  })
);