﻿define(
   ({
    _widgetLabel: "Header-controller",
    signin: "Log ind",
    signout: "Log ud",
    about: "Om",
    signInTo: "Log ind på",
    cantSignOutTip: "Denne funktion er ikke relevant i forhåndsvisningen."
  })
);
