﻿define(
   ({
    _widgetLabel: "Mastelio juosta"
  })
);