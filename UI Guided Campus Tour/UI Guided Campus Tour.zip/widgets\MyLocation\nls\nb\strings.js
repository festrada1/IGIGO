﻿define(
   ({
    _widgetLabel: "Min lokasjon",
    title: "Finn min lokasjon",
    browserError: "Geolokasjon støttes ikke av denne nettleseren.",
    failureFinding: "Kan ikke finne lokasjonen din. Kontroller webleseren din for å sikre at lokasjonen din deles."
  })
);