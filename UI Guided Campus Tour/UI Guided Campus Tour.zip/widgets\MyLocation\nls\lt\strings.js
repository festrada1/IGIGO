﻿define(
   ({
    _widgetLabel: "Mano vieta",
    title: "Rasti mano vietą",
    browserError: "Ši naršyklėje nepalaiko geolokacijos.",
    failureFinding: "Nepavyksta rasti jūsų vietos. Patikrinkite naršyklėje, ar bendrinate savo buvimo vietą."
  })
);