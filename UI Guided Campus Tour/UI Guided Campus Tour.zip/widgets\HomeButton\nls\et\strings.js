﻿define(
   ({
    _widgetLabel: "Avalehe nupp"
  })
);