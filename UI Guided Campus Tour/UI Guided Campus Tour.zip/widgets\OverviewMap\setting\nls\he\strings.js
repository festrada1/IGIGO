﻿define(
   ({
    visible: "הצג מפת התמצאות כברירת מחדל",
    minWidth: "רוחב מינימלי",
    minHeight: "גובה מינימלי",
    maxWidth: "אורך מקסימלי",
    maxHeight: "גובה מקסימלי",
    minText: "מינימום",
    maxText: "מקסימום",
    attachText: "ציין לאיזו פינה של המפה יש להצמיד וידג'ט זה.",
    expandText: "הרחבה ראשונית של הוידג'ט",
    topLeft: "צד שמאל למעלה",
    topRight: "צד ימין למעלה",
    bottomLeft: "צד שמאל למטה",
    bottomRight: "צד ימין למטה"
  })
);