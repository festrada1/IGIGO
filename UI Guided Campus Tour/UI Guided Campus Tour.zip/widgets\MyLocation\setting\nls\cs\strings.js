﻿define(
   ({
    timeout: "Časový limit vypršel",
    highlightLocation: "Zvýraznit polohu",
    useTracking: "Sledovat změny umístění",
    warning: "Nesprávný vstup"
  })
);