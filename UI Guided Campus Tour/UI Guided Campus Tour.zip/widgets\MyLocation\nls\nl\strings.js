﻿define(
   ({
    _widgetLabel: "Mijn locatie",
    title: "Mijn locatie zoeken",
    browserError: "Geografische locatie wordt niet ondersteund door deze browser.",
    failureFinding: "Kan uw locatie niet vinden. Controleer uw browser om er zeker van te zijn dat uw locatie wordt gedeeld."
  })
);