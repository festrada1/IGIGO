﻿define(
   ({
    timeout: "Skirto laiko pabaiga",
    highlightLocation: "Išryškinti vietą",
    useTracking: "Žiūrėti vietos pakeitimus",
    warning: "Klaidinga įvestis"
  })
);