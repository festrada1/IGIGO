﻿define(
   ({
    unit: "יחידה",
    style: "סגנון",
    dual: "דואלי",
    english: "אנגלי",
    metric: "מטרי",
    ruler: "סרגל",
    line: "קו"
  })
);