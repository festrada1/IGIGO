﻿define(
   ({
    unit: "Enhed",
    style: "Typografi",
    dual: "dobbelt",
    english: "metric",
    metric: "metric",
    ruler: "lineal",
    line: "linje"
  })
);