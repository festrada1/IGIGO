﻿define(
   ({
    _widgetLabel: "Målestok"
  })
);