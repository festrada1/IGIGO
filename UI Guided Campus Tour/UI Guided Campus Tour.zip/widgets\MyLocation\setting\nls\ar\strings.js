﻿define(
   ({
    timeout: "انتهاء",
    highlightLocation: "تمييز الموقع",
    useTracking: "لاحظ تغييرات المواقع",
    warning: "مدخلات غير صحيحة"
  })
);