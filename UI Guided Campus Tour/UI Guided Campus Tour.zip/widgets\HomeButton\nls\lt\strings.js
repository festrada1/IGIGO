﻿define(
   ({
    _widgetLabel: "Pradžios mygtukas"
  })
);